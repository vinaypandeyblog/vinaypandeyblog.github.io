
title: My humbel observations -
layout: post
date: 29/10/2017, 11:29
author: Vinay Pandey
tags: [रवि दर्शन, दीर्घ]

---

Amid hype of U17 Fifa finale , cricket tri series and french open, yesterday thrilling finale took place  in PKL ( Pro Kabbadi League). 


In 3 month long league, with its unassailable defence, Gujrat was on the top of the table since begining. .On the other hand, in the initial matches, Patna defence was a pity. It was more a lone battle by its captain, the phenomenal raider Pradeep Narwal well supported by Monu Goyat. The journey was a rough one, it survived 3  eliminators to reach the final. Inspired by captins untiring performance Patna defence gradually peaked and yesterday it was better than the best (Gujrat).  Against all odds & predictions, yesterday night, Patna won against "Fortunegiants' by huge 17 point margin. 

*My humbel observations -*

1. One man can turn a tide and turn the fortune of a whole team.

2. In turning the tide, atleast one able associate is needed.

3.An ordinary team gets going when leader performs in an outstanding manner.

4. To be a champion, when the leader performs, all team members must put their best foot forward. 

5 *Never say die.* 

In our tirades, we may also take clue. *Spirit stands above Skill and Resoluteness stands above Resources.*

🙏🙏
