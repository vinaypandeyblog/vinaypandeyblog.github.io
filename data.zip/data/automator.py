import re
from datetime import datetime
import os


def get_length_category(content):
    word_count = len(content.split())
    if word_count < 30:
        return "लघु"
    elif word_count < 100:
        return "मध्यम"
    else:
        return "दीर्घ"
    


def process_chat_log(input_file, output_directory):
    with open(input_file, 'r', encoding='utf-8') as file:
        content = file.read()

    messages = re.split(
        r'\n(?=\d{2}/\d{2}/\d{4}, \d{2}:\d{2} - Vinay Pandey:)', content)

    for message in messages:
        match = re.match(
            r'(\d{2}/\d{2}/\d{4}, \d{2}:\d{2}) - Vinay Pandey: ?(.*)', message, re.DOTALL)
        if match:
            date_time_str, content = match.groups()
            date_time = datetime.strptime(date_time_str, '%d/%m/%Y, %H:%M')

            title_match = re.search(r'\*(.*?)\*', content)
            title = title_match.group(1) if title_match else "Untitled"

            # if the title is too long, truncate it
            if len(title) > 40:
                title = title[:40]

            # Remove the first line (which contains the date, time, and name)
            content = content.split('\n', 1)[1] if '\n' in content else content

            day_of_week = date_time.strftime('%A').lower()
            day_based_tag = day_of_week
            if day_of_week == 'sunday':
                day_based_tag = 'रवि दर्शन'
            elif day_of_week == 'monday':
                day_based_tag = 'सोम का मर्म'
            elif day_of_week == 'tuesday':
                day_based_tag = 'मंगल कामना'
            elif day_of_week == 'wednesday':
                day_based_tag = 'बुध की सुध'
            elif day_of_week == 'thursday':
                day_based_tag = 'गुरु का ग्यान'
            elif day_of_week == 'friday':
                day_based_tag = 'शुक्र की फिक्र'
            elif day_of_week == 'saturday':
                day_based_tag = 'शनि का सच'

            length_category = get_length_category(content)

            filename = f"{date_time.strftime('%d-%m-%Y')}-{title.replace(' ', '-')}.md"
            filename = re.sub(r'[^\w\-.]', '', filename)

            markdown_content = f"""
title: {title}
layout: post
date: {date_time_str}
author: Vinay Pandey
tags: [{day_based_tag}, {length_category}]

---

{content.strip()}
"""

            with open(os.path.join(output_directory, filename), 'w', encoding='utf-8') as output_file:
                output_file.write(markdown_content)


# Usage
input_file = 'bkp.txt'
output_directory = '_posts'
process_chat_log(input_file, output_directory)
